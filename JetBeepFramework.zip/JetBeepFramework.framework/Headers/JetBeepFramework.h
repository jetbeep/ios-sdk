//
//  JetBeepFramework.h
//  JetBeepFramework
//
//  Created by Ruslan on 3/28/17.
//  Copyright © 2017 Syllatech. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for JetBeepFramework.
FOUNDATION_EXPORT double JetBeepFrameworkVersionNumber;

//! Project version string for JetBeepFramework.
FOUNDATION_EXPORT const unsigned char JetBeepFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JetBeepFramework/PublicHeader.h>


